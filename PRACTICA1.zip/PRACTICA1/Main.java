import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

//clase jugador y atributos
class Jugador {
    private static int contadorID = 1;
    private int id;
    private String jugador;
    private String nivel;
    private String juegoFavorito;
    private int puntuacion;
//constructor de clase
    public Jugador(String jugador, String nivel, String juegoFavorito, int puntuacion) {
        this.id = contadorID++;
        this.jugador = jugador;
        this.nivel = nivel;
        this.juegoFavorito = juegoFavorito;
        this.puntuacion = puntuacion;
    }
//metodos para acceder a los atributos
    public int getId() {
        return id;
    }

    public String getJugador() {
        return jugador;
    }

    public String getNivel() {
        return nivel;
    }

    public String getJuegoFavorito() {
        return juegoFavorito;
    }

    public int getPuntuacion() {
        return puntuacion;
    }

    // metodo para actualizar la información del jugador
    public void actualizarJugador(String jugador, String nivel, String juegoFavorito, int puntuacion) {
        this.jugador = jugador;
        this.nivel = nivel;
        this.juegoFavorito = juegoFavorito;
        this.puntuacion = puntuacion;
    }
}
//crear el arraylist y los campos
public class Main extends JFrame {
    private ArrayList<Jugador> jugadores = new ArrayList<>();
    private JTextField txtJugador;
    private JTextField txtNivel;
    private JTextField txtJuegoFavorito;
    private JTextField txtPuntuacion;
    private JTextField txtBuscarId;
    private JTextArea txtAreaJugadores;

    public Main() {
        initialize();
    }

    private void initialize() {
        //crear interfaz gráfica
        setBounds(100, 100, 600, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
// apartado de ingreso de jugador
        JLabel lblJugador = new JLabel("Jugador:");
        lblJugador.setBounds(10, 11, 60, 14);
        getContentPane().add(lblJugador);

        txtJugador = new JTextField();
        txtJugador.setBounds(80, 8, 150, 20);
        getContentPane().add(txtJugador);
        txtJugador.setColumns(10);
// apartado de ingreso de nivel
        JLabel lblNivel = new JLabel("Nivel:");
        lblNivel.setBounds(10, 42, 60, 14);
        getContentPane().add(lblNivel);

        txtNivel = new JTextField();
        txtNivel.setBounds(80, 39, 150, 20);
        getContentPane().add(txtNivel);
        txtNivel.setColumns(10);
// apartado de ingreso de juego favorito
        JLabel lblJuegoFavorito = new JLabel("Juego Favorito:");
        lblJuegoFavorito.setBounds(10, 73, 100, 14);
        getContentPane().add(lblJuegoFavorito);

        txtJuegoFavorito = new JTextField();
        txtJuegoFavorito.setBounds(110, 70, 150, 20);
        getContentPane().add(txtJuegoFavorito);
        txtJuegoFavorito.setColumns(10);
// apartado de ingreso de puntuación
        JLabel lblPuntuacion = new JLabel("Puntuación:");
        lblPuntuacion.setBounds(10, 104, 100, 14);
        getContentPane().add(lblPuntuacion);

        txtPuntuacion = new JTextField();
        txtPuntuacion.setBounds(110, 101, 150, 20);
        getContentPane().add(txtPuntuacion);
        txtPuntuacion.setColumns(10);
//crear el botón de agregar
        JButton btnAgregar = new JButton("Agregar");
        btnAgregar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                agregarJugador();
            }
        });
        btnAgregar.setBounds(10, 130, 100, 23);
        getContentPane().add(btnAgregar);
//texto para hacer cosas con la id
        JLabel lblBuscarId = new JLabel("acciones por ID:");
        lblBuscarId.setBounds(10, 160, 100, 14);
        getContentPane().add(lblBuscarId);

        txtBuscarId = new JTextField();
        txtBuscarId.setBounds(110, 157, 50, 20);
        getContentPane().add(txtBuscarId);
        txtBuscarId.setColumns(10);
//crear botón de buscar
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buscarJugadorPorId();
            }
        });
        btnBuscar.setBounds(170, 156, 90, 23);
        getContentPane().add(btnBuscar);
// crear botón de editar
        JButton btnEditar = new JButton("Editar");
        btnEditar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                editarJugadorPorId();
            }
        });
        btnEditar.setBounds(280, 156, 90, 23);
        getContentPane().add(btnEditar);
// crear botón de eliminar
        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                eliminarJugadorPorId();
            }
        });
        btnEliminar.setBounds(390, 156, 90, 23);
        getContentPane().add(btnEliminar);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 190, 560, 70);
        getContentPane().add(scrollPane);

        txtAreaJugadores = new JTextArea();
        scrollPane.setViewportView(txtAreaJugadores);

        setVisible(true);
    }

    // metodo para agregar jugadores
    private void agregarJugador() {
        String jugador = txtJugador.getText();
        String nivel = txtNivel.getText();
        String juegoFavorito = txtJuegoFavorito.getText();
        String puntuacionStr = txtPuntuacion.getText();

// aviso de errores
        if (!jugador.isEmpty() && !nivel.isEmpty() && !juegoFavorito.isEmpty() && !puntuacionStr.isEmpty()) {
            try {
                int puntuacion = Integer.parseInt(puntuacionStr);
                Jugador nuevoJugador = new Jugador(jugador, nivel, juegoFavorito, puntuacion);
                jugadores.add(nuevoJugador);
                txtAreaJugadores.append("ID: " + nuevoJugador.getId() + ", Jugador: " + nuevoJugador.getJugador() + ", Nivel: " + nuevoJugador.getNivel() + ", Juego Favorito: " + nuevoJugador.getJuegoFavorito() + ", Puntuación: " + nuevoJugador.getPuntuacion() + "\n");
                limpiarCampos();
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "La puntuación debe ser un número entero válido.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Por favor diligencie todos los campos.");
        }
    }

    // metodo para buscar jugadores por ID
    private void buscarJugadorPorId() {
        String idStr = txtBuscarId.getText();
        if (!idStr.isEmpty()) {
            try {
                int id = Integer.parseInt(idStr);
                boolean encontrado = false;
                for (Jugador jugador : jugadores) {
                    if (jugador.getId() == id) {
                        txtAreaJugadores.append("ID: " + jugador.getId() + ", Jugador: " + jugador.getJugador() + ", Nivel: " + jugador.getNivel() + ", Juego Favorito: " + jugador.getJuegoFavorito() + ", Puntuación: " + jugador.getPuntuacion() + "\n");
                        encontrado = true;
                        break;
                    }
                }
                if (!encontrado) {
                    JOptionPane.showMessageDialog(this, "No se encontró ningún jugador con el ID especificado.");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingrese un ID válido (número entero).");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Ingrese el ID del jugador a buscar.");
        }
    }


    // metodo para editar jugadores por ID
private void editarJugadorPorId() {
    String idStr = txtBuscarId.getText();
    if (!idStr.isEmpty()) {
        try {
            int id = Integer.parseInt(idStr);
            boolean encontrado = false;
            for (Jugador jugador : jugadores) {
                if (jugador.getId() == id) {
                    String nuevoJugador = txtJugador.getText();
                    String nuevoNivel = txtNivel.getText();
                    String nuevoJuegoFavorito = txtJuegoFavorito.getText();
                    String nuevaPuntuacionStr = txtPuntuacion.getText();
                    if (!nuevoJugador.isEmpty() && !nuevoNivel.isEmpty() && !nuevoJuegoFavorito.isEmpty() && !nuevaPuntuacionStr.isEmpty()) {
                        try {
                            int nuevaPuntuacion = Integer.parseInt(nuevaPuntuacionStr);
                            jugador.actualizarJugador(nuevoJugador, nuevoNivel, nuevoJuegoFavorito, nuevaPuntuacion);
                            String nuevaInfoJugador = "ID: " + jugador.getId() + ", Jugador: " + jugador.getJugador() + ", Nivel: " + jugador.getNivel() + ", Juego Favorito: " + jugador.getJuegoFavorito() + ", Puntuación: " + jugador.getPuntuacion() + "\n";
                            txtAreaJugadores.append(nuevaInfoJugador);
                            JOptionPane.showMessageDialog(this, "Se actualizó correctamente la ID " + id + ".");
                            encontrado = true;
                            limpiarCampos();
                            break;
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(this, "La puntuación debe ser un número entero válido.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Por favor diligencie todos los campos.");
                    }
                }
            }
            //errores 
            if (!encontrado) {
                JOptionPane.showMessageDialog(this, "No se encontró ningún jugador con el ID especificado.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingrese un ID válido (número entero).");
        }
    } else {
        JOptionPane.showMessageDialog(this, "Ingrese el ID del jugador a editar.");
    }
}


    // metodo para eliminar jugadores por ID
private void eliminarJugadorPorId() {
    String idStr = txtBuscarId.getText();
    if (!idStr.isEmpty()) {
        try {
            int id = Integer.parseInt(idStr);
            boolean encontrado = false;
            for (Jugador jugador : jugadores) {
                if (jugador.getId() == id) {
                    int confirmacion = JOptionPane.showConfirmDialog(this, "¿Está seguro de que desea eliminar al jugador con ID " + id + "?", "Confirmación", JOptionPane.YES_NO_OPTION);
                    if (confirmacion == JOptionPane.YES_OPTION) {
                        jugadores.remove(jugador);
                        txtAreaJugadores.setText("");
                        for (Jugador j : jugadores) {
                            txtAreaJugadores.append("ID: " + j.getId() + ", Jugador: " + j.getJugador() + ", Nivel: " + j.getNivel() + ", Juego Favorito: " + j.getJuegoFavorito() + ", Puntuación: " + j.getPuntuacion() + "\n");
                        }
                        txtAreaJugadores.append("La ID " + id + " ha sido eliminada con éxito.\n");
                    }
                    encontrado = true;
                    limpiarCampos();
                    break;
                }
            }
            if (!encontrado) {
                JOptionPane.showMessageDialog(this, "No se encontró ningún jugador con el ID especificado.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingrese un ID válido (número entero).");
        }
    } else {
        JOptionPane.showMessageDialog(this, "Ingrese el ID del jugador a eliminar.");
    }
}

//metodo para al terminar de llenar los campos limpiar la información para agregar otro
    private void limpiarCampos() {
        txtJugador.setText("");
        txtNivel.setText("");
        txtJuegoFavorito.setText("");
        txtPuntuacion.setText("");
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Main frame = new Main();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}

